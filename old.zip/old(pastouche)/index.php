<?php

if (isset($_POST['url'])) {


$url = $_POST['url'];

// Dossier de téléchargement
$dossier = __DIR__ . "/downloads/";

// Commande yt-dlp
$commande = "/usr/local/bin/yt-dlp"
    . " -x"
    . " --audio-format mp3"
    . " --embed-metadata"
    . " --embed-thumbnail"
    . " --convert-thumbnails jpg"
    . " --parse-metadata " . escapeshellarg("%(uploader|)s:%(meta_artist)s")
    . " -o " . escapeshellarg($dossier . "%(title)s.%(ext)s")
    . " " . escapeshellarg($url);

exec($commande . " 2>&1", $output, $code);

echo "<pre>";
echo "Code retour : " . $code . "\n";
print_r($output);
echo "</pre>";
if ($code !== 0) {
    echo $code;
    die("Une erreur est survenue pendant le téléchargement.");
}

// Récupération du fichier généré
$fichiers = glob($dossier . "*.mp3");

if (empty($fichiers)) {
    die("Fichier audio introuvable.");
}

$fichier = end($fichiers);

// Envoi du fichier au navigateur
header("Content-Type: audio/mpeg");
header("Content-Disposition: attachment; filename=\"" . basename($fichier) . "\"");
header("Content-Length: " . filesize($fichier));

// Transmission du contenu
readfile($fichier);

// Nettoyage
unlink($fichier);

exit;


}?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dl</title>
</head>
<body>

<form method="POST" action="./">
    <input type="url" name="url" placeholder="Lien YouTube..." required>
    <button type="submit">Télécharger</button>
</form> 
    
</body>
</html>
