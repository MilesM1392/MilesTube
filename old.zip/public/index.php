<?php
// Ce code permet de voir les erreurs PHP même sur un serveur en mode production
error_reporting(E_ALL & ~E_DEPRECATED);
ini_set("display_errors", 1);

// Cette méthode est utilisé pour éviter les injections et chargement à distance de bibliothèque
// C'est une méthode simple pour se protéger, au moins un minumum...
define("CHARGE_AUTOLOAD",true);
// Cet include permet de faire l'autoload automatiquement en PHP>5
require_once("inc/poo.inc.php"); 

session_start();
// index.php est le contrôleur, vous devez ajouter les modèles et vues sous
// la forme de classes dans le répertoire ./class

if (isset($_GET['RAZ'])) {
    unset($_SESSION['username']);
    header('Location: ./');
}
// --- Instanciation des classes "obligatoires" -------------------------------------------------------------------------------------------------------------------

//PDO
$dba = new DbAccess();
//LoginManager -> permet de gérer les connexions et inscriptions
$loginmanager = new Loginer($dba);

//-- en-tête du document HTML-------------------------------------------------------------------------------------------------------------------
$debutHtml = new Head();
echo $debutHtml;

//Header de la page
$header = new Header();
echo $header;

// ---Mettre les vues main en dessous-------------------------------------------------------------------------------------------------------------------




// ---Fin du body, tout le contenu doit être plus haut-----------------------------------------------------------------------------------------------------

//Footer de la page (ferme aussi le body et le document html)
//Ajoute aussi les scripts JS à la fin du body
$footer = new Footer();
echo $footer;
